import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submit-status',
  templateUrl: './submit-status.component.html',
  styleUrls: ['./submit-status.component.css']
})
export class SubmitStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
