import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acknowledgement3',
  templateUrl: './acknowledgement3.component.html',
  styleUrls: ['./acknowledgement3.component.css']
})
export class Acknowledgement3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
