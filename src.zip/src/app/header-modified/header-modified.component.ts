import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-modified',
  templateUrl: './header-modified.component.html',
  styleUrls: ['./header-modified.component.css']
})
export class HeaderModifiedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
