import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-caye-refund-req',
  templateUrl: './view-caye-refund-req.component.html',
  styleUrls: ['./view-caye-refund-req.component.css']
})
export class ViewCayeRefundReqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
