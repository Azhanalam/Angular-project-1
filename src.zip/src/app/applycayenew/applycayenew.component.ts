import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-applycayenew',
  templateUrl: './applycayenew.component.html',
  styleUrls: ['./applycayenew.component.css']
})
export class ApplycayenewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
