import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-successful',
  templateUrl: './app-successful.component.html',
  styleUrls: ['./app-successful.component.css']
})
export class AppSuccessfulComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
