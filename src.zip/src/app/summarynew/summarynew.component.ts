import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-summarynew',
  templateUrl: './summarynew.component.html',
  styleUrls: ['./summarynew.component.css']
})
export class SummarynewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
