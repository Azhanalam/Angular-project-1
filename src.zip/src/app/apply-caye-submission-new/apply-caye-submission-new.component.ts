import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apply-caye-submission-new',
  templateUrl: './apply-caye-submission-new.component.html',
  styleUrls: ['./apply-caye-submission-new.component.css']
})
export class ApplyCayeSubmissionNewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
