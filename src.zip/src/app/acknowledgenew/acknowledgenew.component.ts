import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acknowledgenew',
  templateUrl: './acknowledgenew.component.html',
  styleUrls: ['./acknowledgenew.component.css']
})
export class AcknowledgenewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
