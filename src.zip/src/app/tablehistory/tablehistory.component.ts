import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tablehistory',
  templateUrl: './tablehistory.component.html',
  styleUrls: ['./tablehistory.component.css']
})
export class TablehistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
