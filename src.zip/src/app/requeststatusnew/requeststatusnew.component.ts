import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requeststatusnew',
  templateUrl: './requeststatusnew.component.html',
  styleUrls: ['./requeststatusnew.component.css']
})
export class RequeststatusnewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
