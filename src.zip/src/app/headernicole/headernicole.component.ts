import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headernicole',
  templateUrl: './headernicole.component.html',
  styleUrls: ['./headernicole.component.css']
})
export class HeadernicoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
